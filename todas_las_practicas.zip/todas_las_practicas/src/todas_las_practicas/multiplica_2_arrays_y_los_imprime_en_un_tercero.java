/*
Uno de ellos estará rellenado con números aleatorios y el otro apuntara al array 
* anterior, después crea un nuevo array con el primer array (usa de nuevo new con 
* el primer array) con el mismo tamaño que se ha pasado por teclado, rellenalo de 
* nuevo con números aleatorios.

Después, crea un método que tenga como parámetros, los dos arrays y devuelva uno 
* nuevo con la multiplicación de la posición 0 del array1 con el del array2 y así 
* sucesivamente. Por último, muestra el contenido de cada array.

Llama al final al recolector de basura.
 */
package todas_las_practicas;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;


public class multiplica_2_arrays_y_los_imprime_en_un_tercero extends javax.swing.JFrame {
        DefaultListModel LISTA=new DefaultListModel ();
    
      public static void rellenarNumAleatorioArray(int lista[], int a, int b){
        for(int i=0;i<lista.length;i++){
            //Generamos un número entre los parametros pasados
            lista[i]=((int)Math.floor(Math.random()*(a-b)+b));
        }
    }

      
      public  void mostrarArray(int lista[]){
        for(int i=0;i<lista.length;i++){
       
            
               LISTA.addElement("la pocicion   "+i+"      contiene el numero   "+lista[i]);
       ls.setModel(LISTA);
        }
    }
      
      public static int[] multiplicador(int array1[], int array2[]){
        int array3[]=new int[array1.length];
        for(int i=0;i<array1.length;i++){
            array3[i]=array1[i]*array2[i];
        }
        return array3;
    }

    
    
    
    public multiplica_2_arrays_y_los_imprime_en_un_tercero() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        ls = new javax.swing.JList();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jScrollPane1.setViewportView(ls);

        jButton1.setText("ejecuta");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jButton1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 357, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(33, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(77, 77, 77)
                .addComponent(jButton1)
                .addContainerGap(35, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

         //Indicamos el tamaño
        String texto=JOptionPane.showInputDialog("Introduce un tamaño");
        int tamanio=Integer.parseInt(texto);
 
        //Creamos los arrays
        int array1[]=new int [tamanio];
        int array2[];
 
        //Rellenamos el array1
        rellenarNumAleatorioArray(array1, 10, 100);
 
        //Apuntamos el array2 al array1
        array2=array1;
 
        //Creamos un nuevo array, usando el array1. Array1 tendra una nueva direccion.
        array1=new int[tamanio];
 
        //Lo volvemos a rellenar, ya que al crear el array de nuevo no contiene los numeros anteriores
        rellenarNumAleatorioArray(array1, 10, 100);
 
        //Contiene el array con el resultado de multiplicar los valores de los arrays
        int array3[]=multiplicador(array1, array2);
 
        //Mostramos el contenido de los arrays
 
          LISTA.addElement("contenido de array 1   ");
               
        mostrarArray(array1);
           LISTA.addElement("  ");
   
      LISTA.addElement("contenido de array 2 ");
           
        mostrarArray(array2);
 
      LISTA.addElement("  ");
      LISTA.addElement("contenido de array 3 ");
          
        mostrarArray(array3);
 
                //Llamamos al recolector de basura
                System.gc();
        
    }//GEN-LAST:event_jButton1ActionPerformed

   
    public static void main(String args[]) {
     
         
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new multiplica_2_arrays_y_los_imprime_en_un_tercero().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList ls;
    // End of variables declaration//GEN-END:variables
}
