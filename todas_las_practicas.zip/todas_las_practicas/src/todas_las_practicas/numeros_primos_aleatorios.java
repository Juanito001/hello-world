/*
 Crea un array de números de un tamaño pasado por teclado, el array contendrá números aleatorios primos entre los números deseados, por último nos indicar cual es el mayor de todos.

Haz un método para comprobar que el número aleatorio es primo, puedes hacer todos lo métodos que necesites.
 */
package todas_las_practicas;

import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;


public class numeros_primos_aleatorios extends javax.swing.JFrame {
    
    DefaultListModel LISTA=new DefaultListModel ();
    
    
       public static void rellenarNumPrimosAleatorioArray(int lista[], int a, int b){
 
        int i=0;
 
        //Usamos mejor un while, ya que solo aumentara cuando genere un primo
        while(i<lista.length){  
            int num=((int)Math.floor(Math.random()*(a-b)+b)); 
            if (esPrimo(num))
            {             
                
            lista[i]=num;  i++;     
            }
            } 
            
            
               }
       
       
       private static boolean esPrimo (int num)
       {
      int prueba;         int contador=0;
       prueba=(int)Math.sqrt(num);
        for (;prueba>1;prueba--)
        {
           if (num%prueba==0){
                contador+=1;
            } 
        }
        
           if (contador>=1){
            return false;
        }
        else{
            return true;
        }
    }
       
       public void mostrarArray(int lista[]){
        for(int i=0;i<lista.length;i++){
            
              LISTA.addElement("la pocicion   "+i+"      contiene el numero   "+lista[i]);
        lisa.setModel(LISTA);
        
        }
    }
     
    
    
    
    
    
    
//todos los metodos
  
    public numeros_primos_aleatorios() {
        initComponents();
    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        lisa = new javax.swing.JList();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jScrollPane1.setViewportView(lisa);

        jButton1.setText("ejecutar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addContainerGap(26, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(114, 114, 114)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 299, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(28, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(189, 189, 189))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

     //Indicamos el tamaño
        String texto=JOptionPane.showInputDialog("Introduce un tamaño");
        int num[]=new int[Integer.parseInt(texto)];
 
        //Invocamos las funciones
        rellenarNumPrimosAleatorioArray(num, 1, 300);
 
        mostrarArray(num);
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
     
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new numeros_primos_aleatorios().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList lisa;
    // End of variables declaration//GEN-END:variables
}
